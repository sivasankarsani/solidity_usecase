import os

from django.db import models

from .utils import get_parent, upload_path


MIN_SHORT_ID            = 2
MIN_SHORT_NAME          = 2
MAX_SHORT_NAME          = 4
MAX_SHORT_ID            = 8
MAX_LENGTH_SHORT_NAME   = 16
MAX_LENGTH_NAME         = 32
MAX_LENGTH_LONG_NAME    = 64
MAX_LENGTH_ID           = 64
MAX_LENGTH_SUB          = 128
MAX_LENGTH_URL          = 255
MAX_LENGTH_MSG          = 255
MAX_LENGTH_ADDRESS      = 255
MAX_LENGTH_LONG_URL     = 1024
MAX_LENGTH_DETAIL       = 2048

BASE_ATTRIBUTE_CHOICES = tuple((
    (status.lower(), status) for status in ['Integer', 'String', 'Boolean']
))


class BaseModel(models.Model):
    class Meta:
        abstract = True

    def __str__(self):
        pk = str(self.pk)
        name = getattr(self, 'name', '') or str(getattr(self, 'code', ''))
        return pk + ':' + name if name else pk


class BaseTimeModel(BaseModel):
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta(BaseModel.Meta):
        abstract = True


class BaseOrderedModel(BaseTimeModel):
    order = models.PositiveSmallIntegerField(default=0,
                                             help_text='higher order is higher precedence')

    class Meta(BaseTimeModel.Meta):
        abstract = True
        ordering = ("order",)


class BaseActiveManager(models.Manager):
    def get_queryset(self):
        return super().get_queryset().filter(active=True)


class BaseValidManager(models.Manager):
    def get_queryset(self):
        return super().get_queryset().filter(valid=True)


class BaseActiveModel(BaseTimeModel):
    active = models.BooleanField(default=False)

    objects = models.Manager()
    active_objects = BaseActiveManager()

    class Meta(BaseTimeModel.Meta):
        abstract = True


class BaseActiveOrderedModel(BaseOrderedModel):
    active = models.BooleanField(default=False)

    objects = models.Manager()
    active_objects = BaseActiveManager()

    class Meta(BaseOrderedModel.Meta):
        abstract = True


class BaseLog(BaseModel):
    created_at = models.DateTimeField(auto_now_add=True)
    name = models.CharField(max_length=MAX_LENGTH_LONG_NAME)
    message = models.CharField(max_length=MAX_LENGTH_MSG)

    class Meta(BaseModel.Meta):
        abstract = True