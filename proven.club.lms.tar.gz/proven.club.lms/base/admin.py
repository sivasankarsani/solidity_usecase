from django.contrib.admin import register, ModelAdmin, TabularInline
from django.utils.html import format_html
from django.contrib.admin import SimpleListFilter


class BaseEntityAdmin(ModelAdmin):
    list_per_page = 10
    list_display = ['id', 'api']

    def api(self, obj):
        try:
            url = self.api_view.get_url(obj.id)
            return format_html('<a target="_blank" href="%s">View</a>' % url)
        except:
            return

    api.allow_tags = True

class BaseEntityActiveAdmin(BaseEntityAdmin):
    list_filter = ['active']


class BaseLogInline(TabularInline):
    pass

