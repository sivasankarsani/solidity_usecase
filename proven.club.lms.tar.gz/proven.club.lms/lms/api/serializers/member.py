from rest_framework import serializers

from base.api.serializers import (
    BaseModelSerializer,
    BaseListCreateSerializer,
    BaseDetailSerializer
)

from .user import UserDetailSerializer

from ...models import (
    Member
)

from .book import (
    BookListDetailSerializer
)


class MemberListDetailSerializer(BaseListCreateSerializer):
    books = serializers.SerializerMethodField()
    name = serializers.SerializerMethodField()

    class Meta(BaseListCreateSerializer.Meta):
        model = Member
        fields = ['id', 'code', 'name', 'books']
    
    def to_representation(self, instance):
        return super().to_representation(instance)
    
    def get_name(self, instance):
        return getattr(instance.user, "username", None)
    
    def get_books(self, instance):
        return [
            BookListDetailSerializer(io.book).data
            for io in instance.issued_books.all()
        ]


class MemberDetailSerializer(MemberListDetailSerializer):
    user = UserDetailSerializer()

    class Meta(MemberListDetailSerializer.Meta):
        model = Member
        fields =  ['id', 'code', 'user', 'books']
    


class IssuedMemberDetailSerializer(MemberDetailSerializer):
    class Meta(MemberDetailSerializer.Meta):
        fields =  ['id', 'code', 'user']
    
    def to_representation(self, instance):
        data = super().to_representation(instance)
        data['name'] = data['user'].get('username')
        data.pop('user')
        return data
    

class CirculationMemberDetailSerializer(BaseListCreateSerializer):
    name = serializers.SerializerMethodField()

    class Meta(BaseListCreateSerializer.Meta):
        model = Member
        fields = ['code', 'name']
    
    def get_name(self, instance):
        return getattr(instance.user, "username", None)

