from rest_framework import serializers

from base.api.serializers import (
    BaseModelSerializer,
    BaseListCreateSerializer,
    BaseDetailSerializer
)

from .user import UserDetailSerializer

from ...models import (
    Circulation
)

from .book import (
    BookDetailSerializer,
    CirculationBookDetailSerializer
)
from .member import (
    MemberDetailSerializer,
    CirculationMemberDetailSerializer
)


class CirculationListDetailSerializer(BaseListCreateSerializer):
    book = CirculationBookDetailSerializer()
    member = CirculationMemberDetailSerializer()

    class Meta(BaseListCreateSerializer.Meta):
        model = Circulation
        fields = ['id', 'event_type', 'book', 'member']
    
    def to_representation(self, instance):
        return super().to_representation(instance)


class CirculationDetailSerializer(CirculationListDetailSerializer):
    book = BookDetailSerializer()
    member = MemberDetailSerializer()
    



