from base.api.serializers import (
    BaseModelSerializer
)

from ...models import (
    User
)

class UserDetailSerializer(BaseModelSerializer):
    class Meta(BaseModelSerializer.Meta):
        model = User
        fields = ['id', 'username', 'email']