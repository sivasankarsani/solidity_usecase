from rest_framework import serializers

from base.api.serializers import (
    BaseListCreateSerializer,
    BaseDetailSerializer
)

from ...models import (
    Book,
    IssuedBook
)

class BookListDetailSerializer(BaseListCreateSerializer):
    class Meta(BaseListCreateSerializer.Meta):
        model = Book
        fields = ['id', 'name', 'copies', 'status']


class BookDetailSerializer(BaseDetailSerializer):
    class Meta(BaseDetailSerializer.Meta):
        model = Book
        fields = [
            'id', 'name', 'code', 'copies',
            'status', 'isbn', 'author', 'category',
        ]


class IssuedBookDetailSerializer(BookDetailSerializer):
    class Meta(BookDetailSerializer.Meta):
        fields = ['code', 'name']


class IssuedBookListDetailSerializer(BaseListCreateSerializer):
    class Meta(BaseListCreateSerializer.Meta):
        model = IssuedBook
        fields = [
            'id', 'due_date', 'issue_date',
            'member', 'book'
        ]


class IssuedBookDetailSerializer(IssuedBookListDetailSerializer):
    book = BookDetailSerializer()
    member = serializers.SerializerMethodField()

    def get_member(self, instance):
        from .member import IssuedMemberDetailSerializer
        return IssuedMemberDetailSerializer(instance.member).data


class CirculationBookDetailSerializer(BookListDetailSerializer):
    class Meta(BookListDetailSerializer.Meta):
        fields = ['name', 'code']

