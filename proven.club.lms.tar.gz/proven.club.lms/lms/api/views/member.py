from django.db.models import Q, Prefetch

from base.api.views import (
	BaseListView,
	BaseUpdateDetailView,
	
	BaseActiveManagerMixin
)

from ..serializers import (
	MemberListDetailSerializer,
	MemberDetailSerializer
)

from ...models import Book


class MemberListView(BaseActiveManagerMixin, BaseListView):
	serializer_class = MemberListDetailSerializer
      
	def filter_queryset(self, queryset):
		queryset = queryset.select_related('user')
		queryset = queryset.prefetch_related(
		       Prefetch(
                'issued_books__book',
                queryset=Book.active_objects.all(),
				to_attr='books'
            )
        )
		return super().filter_queryset(queryset)
	
    	
class MemberDetailView(BaseUpdateDetailView):
	serializer_class = MemberDetailSerializer