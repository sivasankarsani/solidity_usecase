from base.api.views import (
	BaseListView,
    BaseUpdateDetailView
)

from ..serializers import (
	BookListDetailSerializer,
    BookDetailSerializer,

    IssuedBookListDetailSerializer,
    IssuedBookDetailSerializer

)


class BookListView(BaseListView):
    serializer_class = BookListDetailSerializer

	
class BookDetailView(BaseUpdateDetailView):
     serializer_class = BookDetailSerializer


class IssuedBookListView(BaseListView):
     serializer_class = IssuedBookListDetailSerializer


class IssuedBookDetailView(BaseUpdateDetailView):
     serializer_class = IssuedBookDetailSerializer