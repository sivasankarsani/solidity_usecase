from django.db.models import Q

from base.api.views import (
	BaseListView,
	BaseUpdateDetailView,
	
	BaseActiveManagerMixin
)

from ..serializers import (
	CirculationListDetailSerializer,
	CirculationDetailSerializer
)


class CirculationListView(BaseListView):
	serializer_class = CirculationListDetailSerializer
      
	def filter_queryset(self, queryset):
		return super().filter_queryset(queryset)
	
    	
class CirculationDetailView(BaseUpdateDetailView):
	serializer_class = CirculationDetailSerializer