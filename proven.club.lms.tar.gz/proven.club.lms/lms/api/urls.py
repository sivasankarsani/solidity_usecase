from .views import (
	BookListView,
    BookDetailView,
    IssuedBookListView,
    IssuedBookDetailView,

	MemberListView,
    MemberDetailView,

    CirculationListView,
    CirculationDetailView
)

version = 1

views = [
    BookListView,
    BookDetailView,

    IssuedBookListView,
    IssuedBookDetailView,

    MemberListView,
    MemberDetailView,

    CirculationListView,
    CirculationDetailView

]

urlpatterns = []
[urlpatterns.extend(view.urlpatterns(version)) for view in views]
