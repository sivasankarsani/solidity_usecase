from base.admin import register, BaseEntityActiveAdmin, BaseEntityAdmin

from ..models.book import *

from ..api.views import (
    BookDetailView,
    CirculationDetailView,
    MemberDetailView
)

@register(Book)
class BooKAdmin(BaseEntityActiveAdmin):
    api_view = BookDetailView
    list_display = BaseEntityActiveAdmin.list_display + [
        'code', 'name', 'copies',
        'status',
        'order', 'active',
        'isbn', 'category'
    ]
    list_filter = BaseEntityActiveAdmin.list_filter + ['status', 'category']
    search_fields = ['name', 'code', 'isbn']
    readonly_fields = ('status', 'isbn')


@register(Member)
class MemberAdmin(BaseEntityActiveAdmin):
    api_view = MemberDetailView
    list_display = BaseEntityActiveAdmin.list_display + [
        'code', 'user', 'issued_books', 'active'
    ]
    list_filter = BaseEntityActiveAdmin.list_filter
    search_fields = ('user__username', 'code')

    def issued_books(self, instance):
        return ','.join(
            [o.book.name for o in instance.issued_books.all()
        ])


@register(IssuedBook)
class IssuedBookAdmin(BaseEntityAdmin):
    list_display = BaseEntityAdmin.list_display + [
        'member', 'book', 'issue_date', 'due_date', 'due_fee', 'total_copies'
    ]
    readonly_fields = ('total_copies', 'issue_date')
    def due_fee(self, instance):
        from datetime import datetime
        diff = (instance.due_date - datetime.today().date()).days
        if diff < 0:
            return diff * 50
        return 0

    def total_copies(self, instance):
        return instance.book.copies


@register(Circulation)
class CirculationAdmin(BaseEntityAdmin):
    api_view = CirculationDetailView
    list_display = BaseEntityAdmin.list_display + [
        'event_type', 'book', 'member'
    ]
    raw_id_fields = ('book', 'member')
    list_filter = ['event_type']
