from base.models import (
    MAX_LENGTH_SUB
)
from django.contrib.auth.models import User
from django.db.models.signals import post_save
from django.dispatch import receiver
from datetime import datetime,timedelta

from .base import *

def get_expiry():
    return datetime.today() + timedelta(days=15)

def get_book_code(start=1000, end=10000):
    from random import randint
    return randint(start, end)

def get_isbn():
    codes = [
        get_book_code(1, 9),
        get_book_code(),
        get_book_code()
    ]
    return '-'.join(map(str, codes))

class Book(BaseActiveOrderedModel):
    categories = [
        ('education', 'Education'),
        ('entertainment', 'Entertainment'),
        ('comics', 'Comics'),
        ('biography', 'Biographie'),
        ('history', 'History'),
    ]
    RESERVATION_CHOICES = [
        'reserve',
        'fulfill',
    ]
    STATUS_RESERVE, STATUS_FULFILL = RESERVATION_CHOICES
    status = models.CharField(max_length=MAX_LENGTH_LONG_NAME,
                            choices=((s, s.upper()) for s in RESERVATION_CHOICES), default=STATUS_RESERVE)
    name = models.CharField(max_length=MAX_LENGTH_LONG_NAME)
    isbn = models.CharField(max_length=MAX_LENGTH_NAME, default=get_isbn)
    copies = models.PositiveIntegerField(default=0)
    author = models.CharField(max_length=MAX_LENGTH_NAME)
    category = models.CharField(max_length=MAX_LENGTH_NAME,
                                choices=categories,
                                default='education')
    code = models.PositiveIntegerField(default=get_book_code)
    class Meta(BaseActiveOrderedModel.Meta):
        unique_together = (
            ('name', 'author')
        )
    
    def save(self, *args, **kwargs):
        if self.copies == 0:
            self.status = self.STATUS_RESERVE
        else:
            self.status = self.STATUS_FULFILL

        super().save(*args, **kwargs)


class Member(BaseActiveOrderedModel):
    user = models.OneToOneField(User,on_delete=models.CASCADE)    
    code = models.PositiveIntegerField(default=0)

    class Meta(BaseActiveOrderedModel.Meta):
        unique_together = (
            ('user', 'code')
        )

class IssuedBook(BaseTimeModel):
    issue_date = models.DateField(auto_now=True)
    due_date   = models.DateField(default=get_expiry)
    book       = models.ForeignKey(Book, on_delete=models.CASCADE, related_name='issued_books')
    member     = models.ForeignKey(Member, on_delete=models.CASCADE, related_name='issued_books')

    class Meta(BaseTimeModel.Meta):
        unique_together = (
            ('book', 'member')
        )


@receiver(post_save, sender=IssuedBook, dispatch_uid="update_book_copies")
def update_book_copies(sender, instance, **kwargs):
    copies  = instance.book.copies
    if copies > 0:
        instance.book.copies = copies - 1 
        instance.book.save()


class Circulation(BaseTimeModel):
    EVENT_CHOICES = [
        "checkout",
        "return"
    ]
    EVENT_CHECKOUT, EVENT_RETURN = EVENT_CHOICES
    event_type = models.CharField(max_length=MAX_LENGTH_NAME,
                        choices=((s, s.upper()) for s in EVENT_CHOICES), default=EVENT_CHECKOUT)
    book       = models.ForeignKey(Book, on_delete=models.CASCADE, related_name='circulations')
    member     = models.ForeignKey(Member, on_delete=models.CASCADE, related_name='circulations')

