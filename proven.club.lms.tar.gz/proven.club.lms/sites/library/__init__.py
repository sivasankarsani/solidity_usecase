DEPLOY_DIRS = [
        'base',
        'lms'
]
