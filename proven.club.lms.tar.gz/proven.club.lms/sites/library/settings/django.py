import os

os.environ['APP_LIST'] = str([
                            'lms'
                        ])
try:
    from base.settings.django import *
except Exception as err:
    raise Exception(str(err))

API_APP_LIST = [
                'lms',
            ]

INSTALLED_APPS += ['base']

REST_FRAMEWORK['DEFAULT_PERMISSION_CLASSES'] = [
    'lms.api.permissions.IsAuthenticated'
]